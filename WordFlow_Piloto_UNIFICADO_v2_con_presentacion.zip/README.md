# WordFlow — prototipo Android

Primera versión de prueba de un traductor inglés → español con ventana flotante.

## Qué hace
- Permite escribir una palabra o frase corta en inglés y pedir su traducción al español.
- Puede mostrar una ventana flotante sobre otras aplicaciones después de conceder el permiso Android.
- Diseño inicial azul inspirado en el icono WordFlow.

## Limitaciones de esta primera versión
- No lee automáticamente los subtítulos de YouTube; la palabra se escribe manualmente.
- La traducción utiliza el servicio público MyMemory y requiere internet.
- Es un prototipo para pruebas, no una versión final publicada en una tienda.

## Compilar
El workflow de GitHub Actions compila `app-debug.apk` al subir cambios a `main` o al ejecutarlo manualmente desde Actions.


Actualización piloto: icono WordFlow agregado a los recursos mipmap y fondo de ventana flotante con esquinas redondeadas (22dp). Este ZIP contiene el código fuente; para instalar una APK hay que compilarlo con Android/Gradle.


## Mejoras de la ventana flotante
- Panel con esquinas redondeadas de 22 dp y recorte del contenido al contorno.
- La ventana se puede mover manteniendo presionada la franja del título “WordFlow” y arrastrándola.
- El movimiento queda limitado a los bordes de la pantalla.
