package com.wordflow.app;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import org.json.JSONObject;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class OverlayService extends Service {
    private WindowManager wm;
    private View panel;
    private EditText input;
    private TextView result;
    private TextView sourceFlag, targetFlag, swapButton;
    private boolean spanishToEnglish = false;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onCreate() {
        super.onCreate();
        createNotification();
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return; }
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        showPanel();
    }

    private void createNotification() {
        String channel = "wordflow_overlay";
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(channel, "WordFlow flotante", NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
            ? new Notification.Builder(this, channel) : new Notification.Builder(this);
        b.setContentTitle("WordFlow está activo").setContentText("La ventana flotante está disponible.")
         .setSmallIcon(android.R.drawable.ic_menu_search).setOngoing(true);
        startForeground(7, b.build());
    }

    private GradientDrawable rounded(int color, int strokeColor, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        if (strokeColor != Color.TRANSPARENT) d.setStroke(dp(1), strokeColor);
        return d;
    }

    private TextView circularFlag(String flag) {
        TextView v = new TextView(this);
        v.setText(flag);
        v.setTextSize(24);
        v.setGravity(Gravity.CENTER);
        v.setBackground(rounded(Color.rgb(10, 39, 87), Color.rgb(39, 151, 255), 50));
        v.setClickable(false);
        return v;
    }

    private void showPanel() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(12), dp(10), dp(12), dp(12));
        box.setBackgroundResource(com.wordflow.app.R.drawable.wordflow_panel_bg);
        if (Build.VERSION.SDK_INT >= 21) box.setClipToOutline(true);

        // Centered title bar; dragging this bar moves the whole floating window.
        FrameLayout titleBar = new FrameLayout(this);
        titleBar.setPadding(dp(4), dp(2), dp(4), dp(8));
        TextView heading = new TextView(this);
        heading.setText("WordFlow");
        heading.setTextColor(Color.rgb(0, 225, 238));
        heading.setTextSize(23);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        heading.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-1, dp(38), Gravity.CENTER);
        titleBar.addView(heading, hp);
        TextView closeTop = new TextView(this);
        closeTop.setText("×");
        closeTop.setTextColor(Color.WHITE);
        closeTop.setTextSize(28);
        closeTop.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(dp(36), dp(38), Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        titleBar.addView(closeTop, cp);
        closeTop.setOnClickListener(v -> stopSelf());
        titleBar.setContentDescription("Mantené presionado y arrastrá para mover WordFlow");
        titleBar.setOnTouchListener(new View.OnTouchListener() {
            private float downRawX, downRawY;
            private int startX, startY;
            private WindowManager.LayoutParams params;
            @Override public boolean onTouch(View v, MotionEvent event) {
                if (panel == null || wm == null) return false;
                if (params == null) params = (WindowManager.LayoutParams) panel.getLayoutParams();
                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        downRawX = event.getRawX(); downRawY = event.getRawY();
                        startX = params.x; startY = params.y; return true;
                    case MotionEvent.ACTION_MOVE:
                        params.x = startX + Math.round(event.getRawX() - downRawX);
                        params.y = startY + Math.round(event.getRawY() - downRawY);
                        int screenW = getResources().getDisplayMetrics().widthPixels;
                        int screenH = getResources().getDisplayMetrics().heightPixels;
                        params.x = Math.max(0, Math.min(params.x, Math.max(0, screenW - panel.getWidth())));
                        params.y = Math.max(0, Math.min(params.y, Math.max(0, screenH - panel.getHeight())));
                        try { wm.updateViewLayout(panel, params); } catch (Exception ignored) {}
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL: return true;
                }
                return true;
            }
        });
        box.addView(titleBar, new LinearLayout.LayoutParams(-1, dp(42)));

        // Input row: circular source-language flag beside the editable text.
        LinearLayout inputRow = new LinearLayout(this);
        inputRow.setGravity(Gravity.CENTER_VERTICAL);
        sourceFlag = circularFlag("🇺🇸");
        inputRow.addView(sourceFlag, new LinearLayout.LayoutParams(dp(48), dp(48)));
        input = new EditText(this);
        input.setSingleLine(true);
        input.setTextSize(21);
        input.setHint("Escribí en inglés");
        input.setTextColor(Color.WHITE);
        input.setHintTextColor(Color.LTGRAY);
        input.setPadding(dp(12), 0, dp(8), 0);
        input.setBackground(rounded(Color.rgb(35, 55, 100), Color.rgb(33, 83, 151), 12));
        LinearLayout.LayoutParams inputParams = new LinearLayout.LayoutParams(0, dp(58), 1f);
        inputParams.leftMargin = dp(8);
        inputRow.addView(input, inputParams);
        box.addView(inputRow);

        // Action row: round language-swap control plus the existing translate/close buttons.
        LinearLayout actionRow = new LinearLayout(this);
        actionRow.setGravity(Gravity.CENTER_VERTICAL);
        actionRow.setPadding(0, dp(8), 0, dp(8));
        swapButton = new TextView(this);
        swapButton.setText("⇄");
        swapButton.setTextColor(Color.rgb(0, 225, 238));
        swapButton.setTextSize(27);
        swapButton.setGravity(Gravity.CENTER);
        swapButton.setBackground(rounded(Color.rgb(7, 35, 80), Color.rgb(39, 151, 255), 50));
        actionRow.addView(swapButton, new LinearLayout.LayoutParams(dp(48), dp(48)));
        Button translate = new Button(this);
        translate.setText("Traducir");
        translate.setTextSize(16);
        LinearLayout.LayoutParams trp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        trp.leftMargin = dp(8);
        actionRow.addView(translate, trp);
        Button close = new Button(this);
        close.setText("Cerrar");
        close.setTextSize(16);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, dp(48), 1f);
        clp.leftMargin = dp(6);
        actionRow.addView(close, clp);
        box.addView(actionRow);

        // Output row: destination flag and a larger, more readable translation.
        LinearLayout outputRow = new LinearLayout(this);
        outputRow.setGravity(Gravity.CENTER_VERTICAL);
        targetFlag = circularFlag("🇦🇷");
        outputRow.addView(targetFlag, new LinearLayout.LayoutParams(dp(48), dp(48)));
        result = new TextView(this);
        result.setText("La traducción aparecerá aquí.");
        result.setTextColor(Color.WHITE);
        result.setTextSize(22);
        result.setPadding(dp(12), dp(8), dp(4), dp(8));
        result.setGravity(Gravity.CENTER_VERTICAL);
        result.setBackground(rounded(Color.rgb(13, 43, 91), Color.rgb(33, 83, 151), 12));
        LinearLayout.LayoutParams resultParams = new LinearLayout.LayoutParams(0, -2, 1f);
        resultParams.leftMargin = dp(8);
        outputRow.addView(result, resultParams);
        box.addView(outputRow);

        swapButton.setOnClickListener(v -> swapLanguages());
        translate.setOnClickListener(v -> translateWord());
        close.setOnClickListener(v -> stopSelf());

        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                                               : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
            dp(340), WindowManager.LayoutParams.WRAP_CONTENT, type,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.LEFT;
        p.x = Math.max(0, (getResources().getDisplayMetrics().widthPixels - dp(340)) / 2);
        p.y = dp(90);
        try { wm.addView(box, p); panel = box; }
        catch (Exception e) { stopSelf(); }
    }

    private void swapLanguages() {
        spanishToEnglish = !spanishToEnglish;
        sourceFlag.setText(spanishToEnglish ? "🇦🇷" : "🇺🇸");
        targetFlag.setText(spanishToEnglish ? "🇺🇸" : "🇦🇷");
        input.setHint(spanishToEnglish ? "Escribí en argentino" : "Escribí en inglés");
        result.setText("La traducción aparecerá aquí.");
    }

    private void translateWord() {
        String word = input.getText().toString().trim();
        if (word.isEmpty()) { result.setText("Escribí una palabra primero."); return; }
        result.setText("Traduciendo…");
        final String langPair = spanishToEnglish ? "es|en" : "en|es";
        worker.execute(() -> {
            String translated;
            try {
                String q = URLEncoder.encode(word, "UTF-8");
                URL url = new URL("https://api.mymemory.translated.net/get?q=" + q + "&langpair=" + langPair);
                HttpURLConnection conn = (HttpURLConnection)url.openConnection();
                conn.setConnectTimeout(10000); conn.setReadTimeout(10000);
                BufferedReader r = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8));
                StringBuilder sb = new StringBuilder(); String line;
                while ((line = r.readLine()) != null) sb.append(line);
                r.close(); conn.disconnect();
                JSONObject json = new JSONObject(sb.toString());
                translated = json.getJSONObject("responseData").getString("translatedText");
            } catch (Exception e) {
                translated = "No se pudo traducir. Revisá internet e intentá otra vez.";
            }
            final String out = translated;
            new android.os.Handler(getMainLooper()).post(() -> { if (result != null) result.setText(out); });
        });
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) { return START_NOT_STICKY; }
    @Override public void onDestroy() {
        if (panel != null && wm != null) try { wm.removeView(panel); } catch (Exception ignored) {}
        worker.shutdownNow();
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
