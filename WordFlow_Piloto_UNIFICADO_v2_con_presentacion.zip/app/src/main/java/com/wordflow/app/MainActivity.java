package com.wordflow.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        ImageView poster = new ImageView(this);
        poster.setImageResource(R.drawable.wordflow_presentation);
        poster.setScaleType(ImageView.ScaleType.FIT_CENTER);
        poster.setBackgroundColor(android.graphics.Color.rgb(3, 15, 48));
        poster.setContentDescription("WordFlow: traductor norteamericano y argentino. Tocá para abrir el traductor flotante.");
        poster.setOnClickListener(v -> openTranslator());
        setContentView(poster);
    }

    private void openTranslator() {
        if (Settings.canDrawOverlays(this)) {
            try { startForegroundService(new Intent(this, OverlayService.class)); }
            catch (Exception e) { Toast.makeText(this, "No se pudo iniciar la ventana flotante. Probá de nuevo.", Toast.LENGTH_LONG).show(); }
        } else {
            Intent p = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivity(p);
            Toast.makeText(this, "Activá Mostrar sobre otras aplicaciones y volvé a WordFlow.", Toast.LENGTH_LONG).show();
        }
    }
}
